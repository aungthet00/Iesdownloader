<?php 
function assets($value='')
{
	return base_url('assets/' . $value);
}