###################
ELR IES Generator
###################

Select desired lamps, fixtures and accessories and generate .IES file for your lamps.

*******************
Built With
*******************
PHP 7.4.3
MariaDB 10.4.11
Codeigniter 3
