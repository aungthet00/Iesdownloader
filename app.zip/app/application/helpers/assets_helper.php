<?php

function assets($path ='')
{
	return base_url('assets/' . $path);
}